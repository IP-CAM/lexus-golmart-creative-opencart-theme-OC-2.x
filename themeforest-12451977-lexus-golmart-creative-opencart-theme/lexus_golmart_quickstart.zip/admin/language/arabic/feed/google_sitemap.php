<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'Google Sitemap';

// Text 
$_['text_feed']        = 'تغذية المنتجات';
$_['text_success']     = 'تم التعديل !';
$_['text_edit']        = 'Edit Google Sitemap';

// Entry
$_['entry_status']     = 'الحالة :';
$_['entry_data_feed']  = 'رابط تغذية المنتجات :';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
