<?php 
$_['heading_title'] = 'My Twitter';
?>