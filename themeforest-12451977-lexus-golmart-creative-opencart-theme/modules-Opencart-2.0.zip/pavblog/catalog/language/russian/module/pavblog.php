<?php 
$_['text_write_by'] = 'писать';
$_['text_published_in'] = 'Опубликовано в: ' ;
$_['text_created_date'] = 'Дата создания :';
$_['text_hits'] = 'Просмотров :';
$_['text_comment_count'] = 'Комментарий :';
$_['text_readmore'] = "читать далее" ;
$_['text_leave_a_comment'] = 'Оставить комментарий ';


 $_['error_captcha'] = 'капчи не является правильным';
 $_['error_email'] = 'E-mail не является правильным';
 $_['error_comment'] = 'E-mail не является правильным';
 $_['error_user'] = 'Полное имя не является правильным';
 $_['text_in_related_by_tag'] = 'Похожие блоги по тегам ' ;
/**
 *
 */
 $_['text_children'] = 'Дети ' ;
 $_['text_in_same_category'] = 'То же в категории' ;
 $_['text_list_comments'] = 'Комментарии ' ;
 $_['text_created'] = 'Создано ' ;
 $_['text_postedby'] = 'Автор ' ;
 $_['text_comment_link'] = 'Ссылка на комментарий ' ;
 $_['entry_name'] = 'Полное имя ' ;
 $_['entry_email'] = "Электронная почта" ;
 $_['entry_comment'] = 'Комментарий ' ;
 $_['text_submit'] = "Отправить" ;
 $_['text_tags'] = 'Тэги :';
 
 $_['text_like_this'] = 'Вам нравится эта :';
  $_['entry_captcha'] = 'Captcha ' ;

  $_['filter_blog_header_title'] = 'Фильтр блоги % S' ;
  $_['blogs_latest_header_title'] = 'Последние блоги';

 /* blogcategory модуля */
 // Заголовок
$_['blog_category_heading_title'] = 'Блог категории';

// Подпись под аватаром
$_['text_latest'] = 'Последние ' ;
$_['text_mostviewed'] = 'Самые популярные' ;
$_['text_featured'] = 'Лучшее ' ;
$_['text_bestseller'] = 'Бестселлер ' ;

/* blogcomment модуля */
// Заголовок
$_['blogcomment_heading_title'] = 'Последние комментарии ' ;

$_['text_postedby'] = 'Автор ' ;
/* bloglatest модуля */
// Заголовок
$_['bloglatest_heading_title'] = 'Последние ' ;

// Подпись под аватаром
$_['text_latest'] = 'Последние Блог ' ;
$_['text_mostviewed'] = 'Самые популярные ';
$_['text_featured'] = 'Лучшее ' ;
$_['text_bestseller'] = 'Бестселлер ' ;
$_['entry_show_readmore'] = 'Показать Readmore ';
$_['text_readmore'] = "читать далее" ;
?>