<?php 
$_['text_write_by'] = 'Durch schreiben :';
$_['text_published_in'] = 'In Veröffentlicht :';
$_['text_created_date'] = 'Erstellungsdatum :';
$_['text_hits'] = 'Treffer :';
$_['text_comment_count'] = 'Kommentar: ';
$_['text_readmore'] = 'Mehr ';
$_['text_leave_a_comment'] = 'Leave A Comment ';


$_['error_captcha'] = 'Captcha Code ist nicht korrekt ';
$_['error_email'] = 'E-Mail ist nicht korrekt ';
$_['error_comment'] = 'E-Mail ist nicht korrekt ';
$_['error_user'] = 'Fullname ist nicht korrekt ';
$_['text_in_related_by_tag'] = 'Related Blogs von Tags ';
/**
 *
 */
$_['text_children'] = 'Kinder';
$_['text_in_same_category'] = 'Same In Kategorie ';
$_['text_list_comments'] = 'Kommentare ';
$_['text_created'] = 'Erstellt von ';
$_['text_postedby'] = 'Geschrieben von ';
$_['text_comment_link'] = 'Comment Link ';
$_['Eintragsname'] = 'Vollständiger Name';
$_['entry_email'] = 'E-Mail ';
$_['entry_comment'] = 'Kommentar';
$_['text_submit'] = 'Absenden';
$_['text_tags'] = 'Schlagwörter: ';
 
$_['text_like_this'] = 'Like This :';
 $_['entry_captcha'] = 'Sicherheitscode ';
/**
  *
  */
 $_['filter_blog_header_title'] = 'Filter Blogs von % s';
 $_['blogs_latest_header_title'] = 'Neueste Blogs ';

 /* blogcategory Modul */
  // Unterwegs
$_['blog_category_heading_title'] = 'Blog Kategorie ';

// Text
$_['text_latest'] = 'Neueste';
$_['text_mostviewed'] = 'Meist gesehen ';
$_['text_featured'] = 'Feature ';
$_['text_bestseller'] = 'Best Seller ';

/* blogcomment Modul */
// Unterwegs
$_['blogcomment_heading_title'] = 'Neueste Kommentare ';

$_['text_postedby'] = 'Geschrieben von ';
/* bloglatest Modul */
// Unterwegs
$_['bloglatest_heading_title'] = 'Neueste';

// Text
$_['text_latest'] = 'Letzte Blog ';
$_['text_mostviewed'] = 'Meist gesehen ';
$_['text_featured'] = 'Feature ';
$_['text_bestseller'] = 'Best Seller ';
$_['entry_show_readmore'] = 'Zeige Readmore ';
$_['text_readmore'] = 'Weiterlesen ';
?>