<?php
// Heading 
$_['heading_title'] = 'Pav Mạng xã hội';

// Text
$_['text_default']  = 'Mặc định';
?>