<?php
// Heading 
$_['heading_title'] = 'Pav Social';

// Text
$_['text_default']  = 'Default';
?>