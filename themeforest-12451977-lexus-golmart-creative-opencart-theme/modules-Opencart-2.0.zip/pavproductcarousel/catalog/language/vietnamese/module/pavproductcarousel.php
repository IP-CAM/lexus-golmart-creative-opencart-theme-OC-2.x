<?php
// Heading 
$_['heading_title'] = 'Mới nhất';

// Text
$_['text_latest']  = 'Mới nhất'; 
$_['text_mostviewed']  = 'Sản phẩm xem nhiều nhất'; 
$_['text_featured']  = 'Đặc sắc'; 
$_['text_bestseller']  = 'Bán chạy nhất'; 
$_['text_special']  = 'Sale';
$_['text_toprating']  = 'Đánh giá tốt nhất'; 

$_['text_sale'] = 'Sale';
$_['text_sale_detail'] = 'Lưu: %s';

$_['quick_view'] = 'Chi tiết';

$_['text_featured_oneshop']  = 'Sản phẩm nổi bật';
?>
