<?php 

$_['text_watch_video_testimonial'] = 'Xem Video';
$_['text_testimonial'] = 'Nhận xét khách hàng';
?>