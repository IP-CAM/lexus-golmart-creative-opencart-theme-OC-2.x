<?php


$_['entry_sign_up_for_newsletter'] = "Sign Up For Newsletter";

$_['entry_newsletter'] = "Newsletter";

$_['button_ok'] = "Ok";

$_['button_subscribe'] = "Subscribe";

$_['default_input_text'] = "Your email address";

$_['valid_email'] = "Email is not valid!";

$_['success_post'] = "You have successfully subscribed to this newsletter.";

$_['error_post'] = "This email address is already registered.";

$_['description'] = "Aenean erat lacus, vulputate sit amet ornare a augue.";

?>